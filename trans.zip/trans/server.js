const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const { MongoClient } = require('mongodb');

const app = express();
const port = 3000;

app.use(bodyParser.urlencoded({ extended: true }));

const mongoURI = 'mongodb://localhost:27017';
const dbName = 'tranaport';

// Sample data of trucks
let truckData = [
    { pickup: 'Place 1', destination: 'Place 2', truck_id: 'Truck1', delivery_date: '2023-12-01' },
    { pickup: 'Place 1', destination: 'Place 2', truck_id: 'Truck2', delivery_date: '2023-12-02' },
    { pickup: 'Place 1', destination: 'Place 2', truck_id: 'Truck1', delivery_date: '2023-12-03' },
    { pickup: 'Place 1', destination: 'Place 2', truck_id: 'Truck2', delivery_date: '2023-12-04' },
    
    // Add more sample data as needed
];

// Serve static files from the 'public' directory
app.use(express.static('public'));

// Handle form submissions
app.post('/submitBookingRequest', (req, res) => {
    // Extract form data from req.body
    const pickup = req.body.pickup;
    const destination = req.body.destination;
    const quantity = req.body.quantity;
    const crop = req.body.crop;
    const deliveryDate = req.body.deliveryDate;
    const selectedTruck = req.body.selectedTruck;

   /* // Validate form data (add your own validation logic)
    if (!pickup || !destination || !quantity || !crop || !deliveryDate || !selectedTruck) {
        return res.status(400).send('Incomplete form data. Please fill in all fields and select a truck.');
    }*/

    // Add the new booking request to the truck data
    const newTruck = {
        pickup,
        destination,
        truck_id: selectedTruck,
        delivery_date: deliveryDate,
    };

    truckData.push(newTruck);

    // Respond with a success message
    res.send('Booking request submitted successfully');
});

// Endpoint to fetch trucks based on delivery date
app.get('/getTrucks', (req, res) => {
    const pickup = req.query.pickup;
    const destination = req.query.destination;
    const deliveryDate = req.query.deliveryDate;

    // Filter trucks based on pickup, destination, and delivery date
    const matchingTrucks = truckData.filter(truck => (
        truck.pickup === pickup &&
        truck.destination === destination &&
        truck.delivery_date <= deliveryDate
    ));

    res.json(matchingTrucks);
});

// Serve the HTML page
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
